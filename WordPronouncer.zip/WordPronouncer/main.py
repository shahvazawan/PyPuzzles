import pyttsx3
import tkinter as tk
from tkinter import ttk

def speak():
    text = entry.get()
    if text.lower() == "q":
        print("Program is closing")
        root.destroy()
    else:
        speaker = pyttsx3.init()
        speaker.say(text)
        speaker.runAndWait()

if __name__ == '__main__':
    # Create the GUI window
    root = tk.Tk()
    root.title("RoboSpeaker GUI")

    # Label and Entry widget for user input
    label = ttk.Label(root, text="Enter what you want me to speak:")
    label.pack(pady=10)

    entry = ttk.Entry(root, width=50)
    entry.pack(pady=10)

    # Speak button
    speak_button = ttk.Button(root, text="Speak", command=speak)
    speak_button.pack(pady=10)

    # Quit button
    quit_button = ttk.Button(root, text="Quit", command=root.destroy)
    quit_button.pack(pady=10)

    # Run the GUI main loop
    root.mainloop()
